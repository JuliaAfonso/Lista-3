﻿using System.Security.Cryptography;
using System.Text;

namespace H1Store.Catalogo.Infra.Autenticacao
{
    public class Login
    {
        private readonly Dictionary<string, string> userCredentials;

        public bool Autenticacao()
        {

            Console.Write("Digite o nome de usuário: ");
            string username = Console.ReadLine();

            Console.Write("Digite a senha: ");
            string password = Console.ReadLine();

            if (userCredentials.ContainsKey(username) && VerifyPassword(password, userCredentials[username]))
            {
                return true; // Login bem-sucedido
            }
            else
            {
                return false; // Login falhou
            }
        }

        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }

        private bool VerifyPassword(string password, string hashedPassword)
        {
            return HashPassword(password) == hashedPassword;
        }
    }
}