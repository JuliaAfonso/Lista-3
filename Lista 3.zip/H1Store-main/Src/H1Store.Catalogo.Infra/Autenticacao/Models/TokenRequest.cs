﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace H1Store.Catalogo.Infra.Autenticacao.Models
{
	public class TokenRequest
	{
		public string usuario { get; set; }
	}
}
